Put these files on your server.

For example, on my server I put gps.php on http://herverenault.fr/gps
and the i-am-here* files on http://herverenault.fr/self-hosted-gps-tracker/demo/
So you can go to http://herverenault.fr/self-hosted-gps-tracker/demo/i-am-here
and see where the last user runned the demo.
