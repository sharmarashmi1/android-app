<?php
readfile("/tmp/gps-position.txt");
?>
