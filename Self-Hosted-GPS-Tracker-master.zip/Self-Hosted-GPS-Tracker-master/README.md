self-hosted-gps-tracker
=======================

This small Android app sends your GPS coordinates to *your* server. It's your data, do what *you* want with it.

This is how it works :

![how it works.png](how-it-works.png)
